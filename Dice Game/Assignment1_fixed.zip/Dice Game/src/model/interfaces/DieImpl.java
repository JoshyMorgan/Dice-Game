package model.interfaces;

import model.interfaces.Die;
import java.util.*;

public class DieImpl implements Die {
    public int number;
    public int value;
    public int numFaces;

    public DieImpl(int number, int value, int numFaces) throws IllegalArgumentException{
        this.number = number;
        this.value = value;
        this.numFaces = numFaces;
        if (number < 1 || number > 2 || value < 1 || value > numFaces || numFaces < 1){
            throw new IllegalArgumentException();
        }
    }

    @Override
    public int getNumber() {
        return number;
    }
    
    //return random value and set random value
    @Override
    public int getValue() {
        Random rand = new Random();
        int randomValue = (rand.nextInt(this.numFaces)+1);
        this.value = randomValue;
        return randomValue;
    }

    @Override
    public int getNumFaces() {
        return numFaces;
    }
    
    //return value without randomise value
    public int getFinalValue() {
    	return this.value;
    }
    
    @Override
    public boolean equals(Die die) {
        return die.getNumber() == this.getNumber() && die.getValue() == this.getValue();
    }
}
