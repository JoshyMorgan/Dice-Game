package model;
import java.util.*;

import model.interfaces.DicePair;
import model.interfaces.Die;

public class DicePairImpl implements DicePair{

    private DieImpl dieOne;
    private DieImpl dieTwo;

    public DicePairImpl(){
        Random rand1 = new Random();
        int num1 = rand1.nextInt(5)+1;
        dieOne = new DieImpl(1,num1,6);
        num1 = rand1.nextInt(5)+1;
        dieTwo = new DieImpl(2, num1, 6);
    }

    public int getTotal(){
        return (dieOne.value + dieTwo.value);
    }

    @Override
    public boolean equals(DicePair dicePair) {
        if (dicePair.getDie1().equals(this.dieOne)){
            return dicePair.getDie2().equals(this.dieOne);
        }
        return false;
    }

    @Override
    public boolean equals(Object dicePair) {
        if (dicePair instanceof DicePairImpl){
            if (this.dieOne.equals(((DicePairImpl) dicePair).getDie1())){
                return this.dieTwo.equals(((DicePairImpl) dicePair).getDie2());
            }
        }
        return false;
    }

    public Die getDie1(){
        return this.dieOne;
    }

    public Die getDie2(){
        return this.dieTwo;
    }

    @Override
    public int hashCode() {
        return Objects.hash(dieOne, dieTwo);
    }

    @Override
    public String toString() {
        return String.format("Dice %s: %s, Dice %s: %s.. Total: %s",
                this.getDie1().getNumber(), dieOne.getValue(),
                this.getDie2().getNumber(), dieTwo.getValue(), this.getTotal());
    }

    @Override
    public int compareTo(DicePair dicePair) {
        return Integer.compare(this.getTotal(), dicePair.getTotal());
    }
}
