package model;

import model.interfaces.Die;
import java.util.*;

public class DieImpl implements Die {
    public int number;
    public int value;
    public int numFaces;

    public DieImpl(int number, int value, int numFaces) throws IllegalArgumentException{
    	if (number < 1 || number > 2 || value < 1 || value > numFaces || numFaces < 1){
            throw new IllegalArgumentException();
        }
        this.number = number;
        this.value = value;
        this.numFaces = numFaces;
        
    }

    @Override
    public int getNumber() {
        return number;
    }
    
    @Override
    public int getValue() {
        return value;
    }

    @Override
    public int getNumFaces() {
        return numFaces;
    }
    
    
    @Override
    public boolean equals(Die die) {
        return die.getNumber() == this.getNumber() && die.getValue() == this.getValue();
    }
    
    public boolean equals(Object die) {
    	if (die instanceof Die) {
    		return ((Die) die).getValue() == this.getValue() && ((Die) die).getNumFaces() == this.getNumFaces();
    	}
    	return false;
    }
}
